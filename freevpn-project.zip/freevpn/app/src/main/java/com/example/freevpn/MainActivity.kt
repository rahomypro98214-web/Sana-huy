package com.example.freevpn

import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

class MainActivity : ComponentActivity() {
    private lateinit var vpn: VpnManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vpn = VpnManager(this)
        val servers = loadServers()

        setContent {
            var connected by remember { mutableStateOf(false) }
            var selected by remember { mutableStateOf(servers.first()) }

            val permissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    vpn.connect(selected)
                    connected = true
                }
            }

            MaterialTheme(colorScheme = darkColorScheme()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0E1116))
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("VPN مجاني", fontSize = 22.sp)
                    Spacer(Modifier.height(24.dp))

                    Button(
                        onClick = {
                            if (connected) {
                                vpn.disconnect()
                                connected = false
                            } else {
                                val intent = VpnService.prepare(this@MainActivity)
                                if (intent != null) permissionLauncher.launch(intent)
                                else {
                                    vpn.connect(selected)
                                    connected = true
                                }
                            }
                        },
                        modifier = Modifier.size(176.dp)
                    ) {
                        Text(if (connected) "إيقاف" else "اتصال", fontSize = 20.sp)
                    }

                    Text(if (connected) "متصل" else "غير متصل", fontSize = 18.sp)
                    Spacer(Modifier.height(16.dp))

                    servers.forEach { server ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selected = server }
                        ) {
                            Text(
                                server.name,
                                modifier = Modifier.padding(16.dp),
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }

    private fun loadServers(): List<Server> {
        val json = JSONArray(assets.open("servers.json").bufferedReader().readText())
        return List(json.length()) { i ->
            val o = json.getJSONObject(i)
            Server(o.getString("name"), o.getString("country"), o.getString("config"))
        }
    }
}
