package com.example.freevpn

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader

data class Server(val name: String, val country: String, val config: String)

class VpnManager(context: Context) {
    private val backend = GoBackend(context.applicationContext)
    private val tunnel = object : Tunnel {
        override fun getName() = "freevpn"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    fun connect(server: Server) {
        val config = Config.parse(BufferedReader(StringReader(server.config)))
        backend.setState(tunnel, Tunnel.State.UP, config)
    }

    fun disconnect() {
        backend.setState(tunnel, Tunnel.State.DOWN, null)
    }
}
